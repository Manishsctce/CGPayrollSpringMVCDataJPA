package com.cg.payroll.controllers;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
@Controller
public class AuthorizationController {
	@Autowired
	PayrollServices payrollServices;
	@RequestMapping("/authUser")
	public String verifyUser(@Valid@ModelAttribute("associate")Associate associate,BindingResult result) throws AssociateDetailsNotFound, PayrollServicesDownException{
			if(result.hasFieldErrors("associateId")||result.hasFieldErrors("password")) return "loginPage";
			Associate associate2=payrollServices.getAssociateDetails(associate.getAssociateID());
			if(associate.getPassword().equals(associate2.getPassword())){
				payrollServices.calaculateNetSalary(associate.getAssociateID());
				return "menuPage";
			}
			
			return "errorPage";
		
		
	}
}
