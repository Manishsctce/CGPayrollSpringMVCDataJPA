package com.cg.payroll.aspectcontroller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFound;

@ControllerAdvice("com.cg.payroll.controllers")
public class AspectController {
	@ExceptionHandler(AssociateDetailsNotFound.class)
 public ModelAndView associateDetailsNotFound(){
	ModelAndView modelAndView=new ModelAndView();
	modelAndView.addObject("assocaite.firstName", "Enter Correct AssociateId");
	modelAndView.addObject("associate", new Associate());
	modelAndView.setViewName("loginPage");
	 return modelAndView;
 }
}
